# NetRunner VPN — iOS client (WireGuard / AmneziaWG)

A from-scratch iOS WireGuard client with a Cyberpunk-2077-inspired HUD,
config import, a multi-server list, and native support for the
AmneziaWG obfuscation extension (Jc/Jmin/Jmax junk packets, S1/S2
header padding, H1–H4 magic headers).

This repo is **source code, not a buildable .ipa**. iOS requires a
Network Extension (the actual VPN tunnel process), Apple code signing,
and a real device or simulator session — none of which can run inside
a sandboxed code environment. Follow the steps below in Xcode on your
own Mac.

## What's here

```
NetRunnerVPN/
  NetRunnerVPN/                 ← host app (SwiftUI)
    NetRunnerVPNApp.swift
    Design/                     ← Theme.swift, ScanlinePulse.swift
    Models/                     ← ServerProfile.swift
    Services/                   ← ConfigImporter, ServerStore, TunnelController
    Views/                      ← HomeView, ServerRow, ImportConfigView, ServerDetailView
    NetRunnerVPN.entitlements
  NetRunnerVPNTunnel/            ← Network Extension target
    PacketTunnelProvider.swift
    Info.plist
    NetRunnerVPNTunnel.entitlements
```

There is **no `.xcodeproj` here** — generating a valid Xcode project
file by hand is fragile and Apple changes the format often enough that
a hand-rolled one tends to break. Instead, create the project fresh in
Xcode (5 minutes) and drag these files in. Steps below.

## 1. Create the Xcode project

1. Xcode → File → New → Project → **iOS → App**.
2. Product Name: `NetRunnerVPN`. Interface: **SwiftUI**. Language: **Swift**.
3. Set your own Team and a unique bundle ID, e.g. `com.yourteam.netrunnervpn`.
4. Delete the auto-generated `ContentView.swift` and the default
   `NetRunnerVPNApp.swift` — you'll use the ones from this repo.
5. Drag the `NetRunnerVPN/NetRunnerVPN/` folder's contents (Design,
   Models, Services, Views, NetRunnerVPNApp.swift) into the project
   navigator, under the `NetRunnerVPN` group. Make sure "Copy items if
   needed" is checked and the target membership is the main app.
6. Drag in `NetRunnerVPN.entitlements` too (target membership: main app).

## 2. Add the Network Extension target

1. File → New → Target → **Network Extension** → choose **Packet Tunnel
   Provider** → Next.
2. Product Name: `NetRunnerVPNTunnel`. This creates a new folder/group
   with its own `PacketTunnelProvider.swift` and `Info.plist` —
   **delete Xcode's generated versions** and drag in this repo's
   `NetRunnerVPNTunnel/` files instead (same target membership: the
   `NetRunnerVPNTunnel` extension target only).
3. Give the extension target the bundle ID
   `com.yourteam.netrunnervpn.tunnel` (must be the main app's bundle ID
   + a suffix). This **must match** the `tunnelBundleID` constant in
   `TunnelController.swift` — update that constant if you used a
   different ID.

## 3. Add WireGuardKit (the AmneziaWG-capable fork)

The official `WireGuard/wireguard-apple` package does **not** know
about the AmneziaWG obfuscation fields. Use Amnezia's fork instead,
which adds them to `InterfaceConfiguration`:

1. In Xcode: File → Add Package Dependencies.
2. URL: `https://github.com/amnezia-vpn/amneziawg-apple`
3. Add the **WireGuardKit** product to **both** targets: the main app
   target (`NetRunnerVPN`) and the extension target
   (`NetRunnerVPNTunnel`).

### Known gotcha: the Go bridge static library

WireGuardKit links against a `wireguard-go-bridge` static library
written in Go, and Swift Package Manager **cannot build Go code
automatically**. The package's own README walks through adding an
"External Build System" target that shells out to `make`/`go build`.
This is a one-time setup step required by the upstream library, not
something specific to this project — follow the "Building" section at
<https://github.com/amnezia-vpn/amneziawg-apple> exactly; skipping it
produces linker errors like `Undefined symbol: _wgTurnOn`.

You'll need Go installed (`brew install go`) for that build step to
succeed.

## 4. App Group (required for the app ↔ extension boundary)

1. Select the `NetRunnerVPN` target → Signing & Capabilities → +
   Capability → **App Groups** → create
   `group.com.yourteam.netrunnervpn`.
2. Select the `NetRunnerVPNTunnel` target → Signing & Capabilities → +
   Capability → **App Groups** → check the same group.
3. Both `.entitlements` files in this repo already reference that
   group ID — rename it consistently everywhere if you pick a
   different one (it must also match your bundle ID prefix to be
   accepted by Apple's provisioning).

## 5. Network Extension capability + entitlement

1. Main app target → Signing & Capabilities → + Capability →
   **Network Extensions** → check **Packet Tunnel Provider**.
2. This requires the `com.apple.developer.networking.networkextension`
   entitlement, which Apple grants automatically for development
   provisioning profiles. For **App Store distribution** you must
   request the *Network Extension* entitlement from Apple Developer
   support first — this is a manual approval step Apple runs for every
   VPN app, budget a few days for it.

## 6. Build & run

1. Select the `NetRunnerVPN` scheme, a real device (Network Extensions
   are flaky on the Simulator for actual tunneling — fine for UI work,
   not for a real connection).
2. Build. First launch will prompt "NetRunner VPN wants to add VPN
   configurations" — accept; this is `NETunnelProviderManager.saveToPreferences()`
   from `TunnelController.swift` registering the profile.
3. Tap **+** → paste or import an AmneziaWG `.conf` → tap the node →
   **CONNECT TO THIS NODE**.

## Before you ship

- `ServerStore` currently persists private keys in a plain JSON file
  under Application Support. Fine for development; **move keys to the
  Keychain** (with the app-group Keychain access group so the
  extension can read them too) before any real distribution.
- Update `tunnelBundleID` in `TunnelController.swift` and the app
  group string in both `.entitlements` files to match whatever bundle
  ID / team you actually provision with.
- `WireGuardAdapter`'s exact initializer and `InterfaceConfiguration`
  field names can shift between WireGuardKit releases — if you pull a
  newer commit of `amneziawg-apple` and get build errors in
  `PacketTunnelProvider.swift`, check that package's current
  `InterfaceConfiguration.swift` for the AmneziaWG field names (they've
  been `junkPacketCount` / `junkPacketMinSize` / etc. as of this
  writing, but pin a known-good commit/tag rather than tracking `main`).

## License note

WireGuardKit (the `amneziawg-apple` package) is distributed under the
MIT license; the AmneziaWG protocol/library itself and the original
AmneziaWG app are GPLv2/GPLv3-licensed in places — check the specific
repo you depend on. If you distribute a built app that links GPL-
licensed code, you take on the GPL's source-availability obligations
for the binary you ship. This project's own code (everything in this
repo) you're free to license as you like, but the obligations of any
upstream dependency you add travel with your final binary regardless
of this file.
