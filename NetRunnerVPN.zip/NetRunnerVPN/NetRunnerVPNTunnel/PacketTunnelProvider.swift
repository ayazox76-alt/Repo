//
//  PacketTunnelProvider.swift
//  NetRunnerVPNTunnel  (Network Extension target)
//
//  This is the process iOS actually runs the WireGuard/AmneziaWG tunnel
//  in. It reads the dictionary the main app stored in
//  protocolConfiguration.providerConfiguration (see TunnelController.swift)
//  and hands it to WireGuardKit's adapter, which understands the
//  AmneziaWG Jc/Jmin/Jmax/S1/S2/H1-H4 keys natively (amnezia-vpn fork of
//  WireGuardKit — see README for the SPM package URL).
//
//  This file compiles against WireGuardKit's public API as of the
//  amnezia-vpn/amneziawg-apple fork. If you pull a newer version of the
//  package, check WireGuardAdapter's initializer signature hasn't moved.
//

import NetworkExtension
import WireGuardKit
import os.log

class PacketTunnelProvider: NEPacketTunnelProvider {

    private lazy var adapter: WireGuardAdapter = {
        WireGuardAdapter(with: self) { logLevel, message in
            os_log("%{public}@", log: .default, type: logLevel == .error ? .error : .debug, message)
        }
    }()

    override func startTunnel(
        options: [String: NSObject]?,
        completionHandler: @escaping (Error?) -> Void
    ) {
        guard let proto = protocolConfiguration as? NETunnelProviderProtocol,
              let providerConfig = proto.providerConfiguration else {
            completionHandler(TunnelProviderError.missingConfiguration)
            return
        }

        guard let tunnelConfiguration = Self.buildTunnelConfiguration(from: providerConfig) else {
            completionHandler(TunnelProviderError.invalidConfiguration)
            return
        }

        adapter.start(tunnelConfiguration: tunnelConfiguration) { error in
            completionHandler(error)
        }
    }

    override func stopTunnel(
        with reason: NEProviderStopReason,
        completionHandler: @escaping () -> Void
    ) {
        adapter.stop { _ in
            completionHandler()
        }
    }

    override func handleAppMessage(_ messageData: Data, completionHandler: ((Data?) -> Void)?) {
        // Reserved for a future stats channel (bytes in/out, handshake age)
        // queried by the main app while connected. Not required for v1.
        completionHandler?(nil)
    }

    // MARK: - Config translation

    /// Builds a WireGuardKit TunnelConfiguration from the plain dictionary
    /// the main app sent over. WireGuardKit's own `String(describing:)`
    /// based `.conf` parser would also work here, but building the typed
    /// config directly avoids a round-trip through text.
    private static func buildTunnelConfiguration(from config: [String: Any]) -> TunnelConfiguration? {
        guard
            let privateKeyString = config["PrivateKey"] as? String,
            let privateKey = PrivateKey(base64Key: privateKeyString),
            let addressString = config["Address"] as? String,
            let publicKeyString = config["PublicKey"] as? String,
            let publicKey = PublicKey(base64Key: publicKeyString),
            let endpointString = config["Endpoint"] as? String,
            let endpoint = Endpoint(from: endpointString)
        else {
            return nil
        }

        var interface = InterfaceConfiguration(privateKey: privateKey)
        interface.addresses = addressString
            .split(separator: ",")
            .compactMap { IPAddressRange(from: $0.trimmingCharacters(in: .whitespaces)) }

        if let dnsString = config["DNS"] as? String {
            interface.dns = dnsString
                .split(separator: ",")
                .compactMap { DNSServer(from: $0.trimmingCharacters(in: .whitespaces)) }
        }
        if let mtu = config["MTU"] as? Int {
            interface.mtu = UInt16(mtu)
        }

        // AmneziaWG obfuscation parameters. WireGuardKit's
        // InterfaceConfiguration (amnezia-vpn fork) carries these as
        // optional Int/UInt32 fields alongside the standard WireGuard ones.
        interface.junkPacketCount = config["Jc"] as? Int
        interface.junkPacketMinSize = config["Jmin"] as? Int
        interface.junkPacketMaxSize = config["Jmax"] as? Int
        interface.initPacketJunkSize = config["S1"] as? Int
        interface.responsePacketJunkSize = config["S2"] as? Int
        interface.initPacketMagicHeader = config["H1"] as? UInt32
        interface.responsePacketMagicHeader = config["H2"] as? UInt32
        interface.underloadPacketMagicHeader = config["H3"] as? UInt32
        interface.transportPacketMagicHeader = config["H4"] as? UInt32

        var peer = PeerConfiguration(publicKey: publicKey)
        peer.endpoint = endpoint
        if let pskString = config["PresharedKey"] as? String {
            peer.preSharedKey = PreSharedKey(base64Key: pskString)
        }
        if let allowedIPsString = config["AllowedIPs"] as? String {
            peer.allowedIPs = allowedIPsString
                .split(separator: ",")
                .compactMap { IPAddressRange(from: $0.trimmingCharacters(in: .whitespaces)) }
        }
        if let keepalive = config["PersistentKeepalive"] as? Int {
            peer.persistentKeepAlive = UInt16(keepalive)
        }

        return TunnelConfiguration(name: nil, interface: interface, peers: [peer])
    }
}

enum TunnelProviderError: Error, LocalizedError {
    case missingConfiguration
    case invalidConfiguration

    var errorDescription: String? {
        switch self {
        case .missingConfiguration: return "No provider configuration was supplied."
        case .invalidConfiguration: return "Provider configuration could not be parsed into a tunnel config."
        }
    }
}
