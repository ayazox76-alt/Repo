# Building NetRunner VPN without a Mac

This explains the whole path from "I have a GitHub account and an
iPhone" to "the app is installed on my phone," using GitHub's macOS
runners to do the actual compiling. You will still need an Apple
Developer account ($99/year) — that requirement comes from Apple, not
from this setup, and there's no way around it for installing a custom
VPN app outside the App Store sandbox limits.

If you don't want to pay Apple yet, skip straight to **Stage 1** below
and stop there — it proves the code compiles, for free, with zero
Apple account.

---

## Stage 0 — turn this folder into a real Xcode project

GitHub Actions needs an actual `.xcodeproj`, which doesn't exist yet
in this source dump (see main README.md for why). You still need
**one-time access to a Mac** to generate that file — but it can be a
borrowed one, a library Mac, an Apple Store demo unit with a USB
drive, or a cheap one-day cloud Mac rental (MacStadium/MacinCloud have
hourly plans for a few dollars). You're not setting up a dev
environment on it, just clicking through Xcode's "New Project" wizard
once:

1. Follow `README.md` steps 1–5 on that machine (create the project,
   add the extension target, add the WireGuardKit package, configure
   App Groups + Network Extension capability).
2. `git init`, commit, push to a GitHub repo.
3. From here on, you never need that Mac again — GitHub's runners take
   over.

## Stage 1 — free, unsigned compile check (no Apple account needed)

Push to `main` (or run the workflow manually from the Actions tab).
The `build-unsigned` job in `.github/workflows/build.yml` runs
automatically and:

- resolves the WireGuardKit Swift package
- compiles the app for the iOS Simulator with code signing turned off

This catches typos, missing files, and Swift errors for free, on
every push. It **cannot** install anything on a real phone — Apple
does not allow unsigned binaries on physical devices, full stop.

Check the result under your repo's **Actions** tab.

## Stage 2 — get an Apple Developer account

<https://developer.apple.com/programs/> → enroll, $99/year. This is
the unavoidable Apple toll for:
- the Network Extension entitlement (any VPN app needs it)
- installing a build on your own iPhone beyond the 7-day free-account limit
- TestFlight distribution

## Stage 3 — set up Fastlane match (signing, once)

`match` stores your signing certificate and provisioning profile
encrypted in a private git repo, so CI can use them without you ever
touching Xcode's signing UI again.

On any machine with Ruby (your Windows/Linux PC works fine for this
part — `match` itself doesn't need a Mac, only the final `xcodebuild`
step does):

```bash
gem install fastlane
fastlane match init
# choose "git", point it at a new *private* GitHub repo, e.g.
# github.com/you/netrunner-signing-vault
fastlane match appstore
# follow the prompts — this generates and stores the cert + profile
```

You'll be asked for your Apple ID and a passphrase to encrypt the
repo (`MATCH_PASSWORD` below — pick a strong one, store it in a
password manager).

## Stage 4 — create an App Store Connect API key

App Store Connect → Users and Access → **Keys** tab → generate a key
with **App Manager** role. Download the `.p8` file *immediately*
(Apple only lets you download it once). Note the **Key ID** and
**Issuer ID** shown on that page.

## Stage 5 — add GitHub secrets

In your repo: Settings → Secrets and variables → Actions.

**Secrets** (Settings → Secrets and variables → Actions → *Secrets* tab):

| Name | Value |
|---|---|
| `MATCH_GIT_URL` | URL of the private signing repo from Stage 3 |
| `MATCH_PASSWORD` | the passphrase you chose in Stage 3 |
| `FASTLANE_APPLE_ID` | your Apple ID email |
| `TEAM_ID` | found at developer.apple.com/account → Membership |
| `ASC_KEY_ID` | Key ID from Stage 4 |
| `ASC_ISSUER_ID` | Issuer ID from Stage 4 |
| `ASC_KEY_CONTENT` | the `.p8` file's contents, base64-encoded: `base64 -i AuthKey_XXXX.p8 \| pbcopy` (Mac) or `base64 -w0 AuthKey_XXXX.p8` (Linux) |

**Variable** (same screen, *Variables* tab):

| Name | Value |
|---|---|
| `SIGNING_CONFIGURED` | `true` |

That last variable is what flips on the `build-and-deploy` job in the
workflow — it stays off (and the unsigned job keeps running for free)
until you set it.

## Stage 6 — push, get a TestFlight build

Push to `main`. The `build-and-deploy` job now:
1. pulls your cert/profile via `match`
2. bumps the build number
3. builds a signed `.ipa`
4. uploads it to TestFlight via the App Store Connect API key (no
   interactive 2FA — the API key replaces that)

It also attaches the `.ipa` as a downloadable build artifact, in case
you want it for ad-hoc distribution via a service like Diawi instead
of TestFlight.

## Stage 7 — install on your iPhone

Open **TestFlight** (Apple's own free app, on the App Store) on your
iPhone, sign in with the Apple ID you used as `FASTLANE_APPLE_ID` (add
it as an internal tester in App Store Connect if it isn't already),
and install the build from there. No Mac touches your phone at any
point in this stage.

---

## Cost summary

| Item | Cost |
|---|---|
| GitHub Actions macOS runner minutes | Free tier: 2,000 min/month (private repos use a 10x multiplier on macOS minutes — budget accordingly); free for public repos |
| Apple Developer Program | $99/year |
| One-time Mac access (Stage 0 only) | $0 (borrowed) to ~$5 (hourly cloud rental) |
| Everything else in this doc | $0 |
