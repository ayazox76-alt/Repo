//
//  ServerDetailView.swift
//  NetRunner VPN
//
//  Inspect a node's parameters, connect/disconnect, rename, or remove
//  it. The AmneziaWG obfuscation block only renders when the profile
//  actually has those fields set.
//

import SwiftUI

struct ServerDetailView: View {
    let profile: ServerProfile

    @StateObject private var tunnel = TunnelController.shared
    @StateObject private var store = ServerStore.shared
    @Environment(\.dismiss) private var dismiss

    @State private var showRenameAlert = false
    @State private var renameText = ""
    @State private var showDeleteConfirm = false

    private var isActive: Bool { profile.id == tunnel.activeProfileID }
    private var currentState: NRLinkState { isActive ? tunnel.linkState : .idle }

    var body: some View {
        ZStack {
            Color.nrVoid.ignoresSafeArea()

            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    header
                    connectionSection
                    interfaceSection
                    peerSection
                    if profile.usesObfuscation {
                        obfuscationSection
                    }
                    dangerZone
                }
                .padding(NRMetrics.pageMargin)
            }
        }
        .navigationTitle(profile.name)
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(Color.nrVoid, for: .navigationBar)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    renameText = profile.name
                    showRenameAlert = true
                } label: {
                    Image(systemName: "pencil")
                        .foregroundStyle(Color.nrSignal)
                }
            }
        }
        .alert("Rename node", isPresented: $showRenameAlert) {
            TextField("Name", text: $renameText)
            Button("Cancel", role: .cancel) {}
            Button("Save") { store.rename(profile, to: renameText) }
        }
        .confirmationDialog(
            "Remove this node?",
            isPresented: $showDeleteConfirm,
            titleVisibility: .visible
        ) {
            Button("Remove", role: .destructive) {
                if isActive { tunnel.disconnect() }
                store.remove(profile)
                dismiss()
            }
            Button("Cancel", role: .cancel) {}
        }
        .preferredColorScheme(.dark)
    }

    // MARK: - Sections

    private var header: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(profile.usesObfuscation ? "AMNEZIAWG NODE" : "WIREGUARD NODE")
                    .font(NRFont.eyebrow)
                    .foregroundStyle(Color.nrTextMuted)
                    .kerning(1.5)
                Text(profile.hostOnly)
                    .font(NRFont.dataMedium)
                    .foregroundStyle(Color.nrTextPrimary)
            }
            Spacer()
        }
    }

    private var connectionSection: some View {
        VStack(alignment: .leading, spacing: 14) {
            ScanlinePulse(state: currentState)

            Group {
                if isActive, tunnel.linkState == .connected {
                    Button {
                        tunnel.disconnect()
                    } label: {
                        actionLabel("DISCONNECT", color: .nrAlert)
                    }
                } else if isActive, tunnel.linkState == .connecting {
                    actionLabel("NEGOTIATING…", color: .nrCyan, dimmed: true)
                } else {
                    Button {
                        Task { await tunnel.connect(to: profile) }
                    } label: {
                        actionLabel("CONNECT TO THIS NODE", color: .nrSignal)
                    }
                }
            }
        }
        .padding(NRMetrics.cardPadding)
        .nrPanel()
    }

    private var interfaceSection: some View {
        fieldGroup(title: "INTERFACE") {
            field("Address", profile.address)
            if let dns = profile.dns { field("DNS", dns) }
            if let mtu = profile.mtu { field("MTU", "\(mtu)") }
            field("Public key", maskedKey(profile.privateKey))
        }
    }

    private var peerSection: some View {
        fieldGroup(title: "PEER") {
            field("Endpoint", profile.endpoint)
            field("Allowed IPs", profile.allowedIPs)
            field("Peer key", maskedKey(profile.publicKey))
            if let keepalive = profile.persistentKeepalive {
                field("Keepalive", "\(keepalive)s")
            }
        }
    }

    private var obfuscationSection: some View {
        fieldGroup(title: "OBFUSCATION · AMNEZIAWG") {
            if let jc = profile.junkPacketCount { field("Jc", "\(jc)") }
            if let jmin = profile.junkPacketMinSize { field("Jmin", "\(jmin)") }
            if let jmax = profile.junkPacketMaxSize { field("Jmax", "\(jmax)") }
            if let s1 = profile.initHeaderJunkSize { field("S1", "\(s1)") }
            if let s2 = profile.responseHeaderJunkSize { field("S2", "\(s2)") }
            if let h1 = profile.initPacketMagicHeader { field("H1", "\(h1)") }
            if let h2 = profile.responsePacketMagicHeader { field("H2", "\(h2)") }
            if let h3 = profile.underloadPacketMagicHeader { field("H3", "\(h3)") }
            if let h4 = profile.transportPacketMagicHeader { field("H4", "\(h4)") }
        }
    }

    private var dangerZone: some View {
        Button(role: .destructive) {
            showDeleteConfirm = true
        } label: {
            Text("REMOVE NODE")
                .font(NRFont.mono(13, weight: .bold))
                .kerning(1)
                .foregroundStyle(Color.nrAlert)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 12)
                .overlay(NotchedRect().stroke(Color.nrAlert.opacity(0.5), lineWidth: 1))
        }
        .padding(.top, 12)
    }

    // MARK: - Helpers

    private func fieldGroup<Content: View>(title: String, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(title)
                .font(NRFont.eyebrow)
                .foregroundStyle(Color.nrTextMuted)
                .kerning(1.5)
            VStack(alignment: .leading, spacing: 10) {
                content()
            }
            .padding(NRMetrics.cardPadding)
            .nrPanel()
        }
    }

    private func field(_ label: String, _ value: String) -> some View {
        HStack(alignment: .top) {
            Text(label)
                .font(NRFont.caption)
                .foregroundStyle(Color.nrTextMuted)
                .frame(width: 96, alignment: .leading)
            Text(value)
                .font(NRFont.dataSmall)
                .foregroundStyle(Color.nrTextPrimary)
                .textSelection(.enabled)
            Spacer()
        }
    }

    private func maskedKey(_ key: String) -> String {
        guard key.count > 10 else { return key }
        let prefix = key.prefix(6)
        let suffix = key.suffix(4)
        return "\(prefix)…\(suffix)"
    }

    private func actionLabel(_ title: String, color: Color, dimmed: Bool = false) -> some View {
        Text(title)
            .font(NRFont.mono(14, weight: .bold))
            .kerning(1)
            .foregroundStyle(dimmed ? color.opacity(0.6) : Color.nrVoid)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .background(dimmed ? Color.clear : color)
            .overlay(NotchedRect().stroke(color, lineWidth: dimmed ? 1 : 0))
            .clipShape(NotchedRect())
    }
}

#Preview {
    NavigationStack {
        ServerDetailView(profile: ServerProfile(
            name: "Night City Relay",
            privateKey: "iAmYourPrivateKeyExample1234567890=",
            address: "10.8.1.2/32",
            dns: "1.1.1.1",
            publicKey: "iAmThePeerPublicKeyExample1234567890=",
            endpoint: "203.0.113.5:51820",
            junkPacketCount: 4,
            junkPacketMinSize: 40,
            junkPacketMaxSize: 70,
            initHeaderJunkSize: 0,
            responseHeaderJunkSize: 0,
            initPacketMagicHeader: 1234567890,
            responsePacketMagicHeader: 1234567891,
            underloadPacketMagicHeader: 1234567892,
            transportPacketMagicHeader: 1234567893
        ))
    }
}
