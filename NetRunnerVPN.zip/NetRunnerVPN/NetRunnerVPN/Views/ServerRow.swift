//
//  ServerRow.swift
//  NetRunner VPN
//
//  One node in the list: name, host, ping, and a protocol badge that
//  distinguishes plain WireGuard from obfuscated AmneziaWG nodes.
//

import SwiftUI

struct ServerRow: View {
    let profile: ServerProfile
    let isActive: Bool
    let linkState: NRLinkState

    var body: some View {
        HStack(spacing: 14) {
            statusDot

            VStack(alignment: .leading, spacing: 4) {
                Text(profile.name)
                    .font(NRFont.body.weight(.semibold))
                    .foregroundStyle(Color.nrTextPrimary)
                Text(profile.hostOnly)
                    .font(NRFont.dataSmall)
                    .foregroundStyle(Color.nrTextMuted)
            }

            Spacer()

            VStack(alignment: .trailing, spacing: 4) {
                protocolBadge
                if let ping = profile.lastPingMillis {
                    Text("\(ping) ms")
                        .font(NRFont.dataSmall)
                        .foregroundStyle(pingColor(ping))
                }
            }

            Image(systemName: "chevron.right")
                .font(.system(size: 12, weight: .bold))
                .foregroundStyle(Color.nrTextFaint)
        }
        .padding(NRMetrics.cardPadding)
        .nrPanel(edge: isActive ? Color.nrSignal.opacity(0.6) : Color.nrEdge)
    }

    private var statusDot: some View {
        Circle()
            .fill(isActive ? linkState.tint : Color.nrTextFaint)
            .frame(width: 8, height: 8)
            .shadow(color: isActive ? linkState.tint.opacity(0.8) : .clear, radius: 4)
    }

    private var protocolBadge: some View {
        Text(profile.usesObfuscation ? "AWG" : "WG")
            .font(NRFont.mono(10, weight: .bold))
            .kerning(0.5)
            .padding(.horizontal, 6)
            .padding(.vertical, 2)
            .foregroundStyle(profile.usesObfuscation ? Color.nrVoid : Color.nrTextMuted)
            .background(profile.usesObfuscation ? Color.nrCyan : Color.nrSurfaceRaised)
            .clipShape(RoundedRectangle(cornerRadius: 3))
    }

    private func pingColor(_ ms: Int) -> Color {
        switch ms {
        case ..<80: return .nrSignal
        case ..<180: return .nrCyan
        default: return .nrAlert
        }
    }
}

#Preview {
    VStack(spacing: 12) {
        ServerRow(
            profile: ServerProfile(
                name: "Night City Relay",
                privateKey: "x", address: "10.0.0.2/32",
                publicKey: "y", endpoint: "203.0.113.5:51820",
                junkPacketCount: 4, junkPacketMinSize: 40, junkPacketMaxSize: 70,
                lastPingMillis: 42
            ),
            isActive: true,
            linkState: .connected
        )
        ServerRow(
            profile: ServerProfile(
                name: "Pacifica Backup",
                privateKey: "x", address: "10.0.0.3/32",
                publicKey: "y", endpoint: "203.0.113.9:51820",
                lastPingMillis: 210
            ),
            isActive: false,
            linkState: .idle
        )
    }
    .padding()
    .background(Color.nrVoid)
}
