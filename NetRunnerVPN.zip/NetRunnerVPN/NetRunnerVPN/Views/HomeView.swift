//
//  HomeView.swift
//  NetRunner VPN
//
//  The HUD. Big status readout up top, the active node's scanline
//  pulse, a single primary action, then the server list below.
//

import SwiftUI

struct HomeView: View {
    @StateObject private var tunnel = TunnelController.shared
    @StateObject private var store = ServerStore.shared
    @State private var showImporter = false

    private var activeProfile: ServerProfile? {
        store.profiles.first { $0.id == tunnel.activeProfileID }
    }

    var body: some View {
        NavigationStack {
            ZStack {
                Color.nrVoid.ignoresSafeArea()

                ScrollView {
                    VStack(alignment: .leading, spacing: 28) {
                        statusHUD
                        serverSection
                    }
                    .padding(NRMetrics.pageMargin)
                }
            }
            .navigationTitle("")
            .toolbar {
                ToolbarItem(placement: .principal) {
                    Text("NETRUNNER")
                        .font(NRFont.mono(15, weight: .bold))
                        .foregroundStyle(Color.nrTextPrimary)
                        .kerning(2)
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        showImporter = true
                    } label: {
                        Image(systemName: "plus")
                            .foregroundStyle(Color.nrSignal)
                    }
                }
            }
            .toolbarBackground(Color.nrVoid, for: .navigationBar)
            .sheet(isPresented: $showImporter) {
                ImportConfigView()
            }
        }
        .preferredColorScheme(.dark)
        .tint(Color.nrSignal)
    }

    // MARK: - Status HUD

    private var statusHUD: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Text(eyebrowText)
                    .font(NRFont.eyebrow)
                    .foregroundStyle(tunnel.linkState.tint)
                    .kerning(1.5)
                Spacer()
                if let profile = activeProfile {
                    Text(profile.name.uppercased())
                        .font(NRFont.eyebrow)
                        .foregroundStyle(Color.nrTextMuted)
                }
            }

            Text(statusHeadline)
                .font(NRFont.displayLarge)
                .foregroundStyle(Color.nrTextPrimary)
                .nrGlitch(on: tunnel.linkState)

            ScanlinePulse(state: tunnel.linkState)

            primaryAction
        }
        .padding(NRMetrics.cardPadding)
        .nrPanel()
    }

    private var eyebrowText: String {
        switch tunnel.linkState {
        case .idle: return "LINK · OFFLINE"
        case .connecting: return "LINK · NEGOTIATING"
        case .connected: return "LINK · SECURE"
        case .failed: return "LINK · ERROR"
        }
    }

    private var statusHeadline: String {
        switch tunnel.linkState {
        case .idle: return "Disconnected"
        case .connecting: return "Connecting…"
        case .connected: return "Connected"
        case .failed: return "Connection failed"
        }
    }

    @ViewBuilder
    private var primaryAction: some View {
        switch tunnel.linkState {
        case .idle, .failed:
            Button {
                if let profile = activeProfile ?? store.profiles.first {
                    Task { await tunnel.connect(to: profile) }
                }
            } label: {
                actionLabel("CONNECT", color: .nrSignal)
            }
            .disabled(store.profiles.isEmpty)
        case .connecting:
            actionLabel("NEGOTIATING…", color: .nrCyan, dimmed: true)
        case .connected:
            Button {
                tunnel.disconnect()
            } label: {
                actionLabel("DISCONNECT", color: .nrAlert)
            }
        }
    }

    private func actionLabel(_ title: String, color: Color, dimmed: Bool = false) -> some View {
        Text(title)
            .font(NRFont.mono(14, weight: .bold))
            .kerning(1)
            .foregroundStyle(dimmed ? color.opacity(0.6) : Color.nrVoid)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .background(dimmed ? Color.clear : color)
            .overlay(NotchedRect().stroke(color, lineWidth: dimmed ? 1 : 0))
            .clipShape(NotchedRect())
    }

    // MARK: - Server list

    private var serverSection: some View {
        VStack(alignment: .leading, spacing: NRMetrics.stackGap) {
            HStack {
                Text("NODES")
                    .font(NRFont.eyebrow)
                    .foregroundStyle(Color.nrTextMuted)
                    .kerning(1.5)
                Spacer()
                Text("\(store.profiles.count)")
                    .font(NRFont.eyebrow)
                    .foregroundStyle(Color.nrTextFaint)
            }

            if store.profiles.isEmpty {
                emptyState
            } else {
                ForEach(store.profiles) { profile in
                    NavigationLink(value: profile) {
                        ServerRow(
                            profile: profile,
                            isActive: profile.id == tunnel.activeProfileID,
                            linkState: profile.id == tunnel.activeProfileID ? tunnel.linkState : .idle
                        )
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .navigationDestination(for: ServerProfile.self) { profile in
            ServerDetailView(profile: profile)
        }
    }

    private var emptyState: some View {
        VStack(spacing: 10) {
            Image(systemName: "antenna.radiowaves.left.and.right.slash")
                .font(.system(size: 28))
                .foregroundStyle(Color.nrTextFaint)
            Text("No nodes imported")
                .font(NRFont.body)
                .foregroundStyle(Color.nrTextMuted)
            Text("Tap + to bring in a .conf file")
                .font(NRFont.caption)
                .foregroundStyle(Color.nrTextFaint)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 36)
        .nrPanel()
    }
}

#Preview {
    HomeView()
}
