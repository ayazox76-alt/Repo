//
//  ImportConfigView.swift
//  NetRunner VPN
//
//  Two ways in: pick a .conf file from the Files app, or paste raw
//  config text directly (useful when a node is shared as plain text
//  rather than a file attachment).
//

import SwiftUI
import UniformTypeIdentifiers

struct ImportConfigView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var store = ServerStore.shared

    @State private var showFilePicker = false
    @State private var pastedText = ""
    @State private var nameForPaste = ""
    @State private var localError: String?

    var body: some View {
        NavigationStack {
            ZStack {
                Color.nrVoid.ignoresSafeArea()

                ScrollView {
                    VStack(alignment: .leading, spacing: 24) {
                        filePickerCard
                        dividerRow
                        pasteCard

                        if let error = localError ?? store.importError {
                            errorBanner(error)
                        }
                    }
                    .padding(NRMetrics.pageMargin)
                }
            }
            .navigationTitle("Import node")
            .navigationBarTitleDisplayMode(.inline)
            .toolbarBackground(Color.nrVoid, for: .navigationBar)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Cancel") { dismiss() }
                        .foregroundStyle(Color.nrTextMuted)
                }
            }
            .fileImporter(
                isPresented: $showFilePicker,
                allowedContentTypes: [.item],
                allowsMultipleSelection: false
            ) { result in
                handleFileResult(result)
            }
        }
        .preferredColorScheme(.dark)
    }

    private var filePickerCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("FROM FILE")
                .font(NRFont.eyebrow)
                .foregroundStyle(Color.nrTextMuted)
                .kerning(1.5)

            Button {
                showFilePicker = true
            } label: {
                HStack {
                    Image(systemName: "doc.badge.plus")
                        .foregroundStyle(Color.nrSignal)
                    Text("Choose .conf file")
                        .font(NRFont.body.weight(.semibold))
                        .foregroundStyle(Color.nrTextPrimary)
                    Spacer()
                    Image(systemName: "chevron.right")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundStyle(Color.nrTextFaint)
                }
                .padding(NRMetrics.cardPadding)
                .nrPanel()
            }
            .buttonStyle(.plain)
        }
    }

    private var dividerRow: some View {
        HStack {
            Rectangle().fill(Color.nrEdge).frame(height: 1)
            Text("OR")
                .font(NRFont.eyebrow)
                .foregroundStyle(Color.nrTextFaint)
            Rectangle().fill(Color.nrEdge).frame(height: 1)
        }
    }

    private var pasteCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("PASTE CONFIG")
                .font(NRFont.eyebrow)
                .foregroundStyle(Color.nrTextMuted)
                .kerning(1.5)

            TextField("Node name", text: $nameForPaste)
                .font(NRFont.body)
                .foregroundStyle(Color.nrTextPrimary)
                .padding(NRMetrics.cardPadding)
                .nrPanel()

            TextEditor(text: $pastedText)
                .font(NRFont.mono(13))
                .foregroundStyle(Color.nrTextPrimary)
                .scrollContentBackground(.hidden)
                .frame(height: 180)
                .padding(8)
                .nrPanel()
                .overlay(alignment: .topLeading) {
                    if pastedText.isEmpty {
                        Text("[Interface]\nPrivateKey = …")
                            .font(NRFont.mono(13))
                            .foregroundStyle(Color.nrTextFaint)
                            .padding(16)
                            .allowsHitTesting(false)
                    }
                }

            Button {
                importPasted()
            } label: {
                Text("IMPORT")
                    .font(NRFont.mono(14, weight: .bold))
                    .kerning(1)
                    .foregroundStyle(Color.nrVoid)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(canImportPasted ? Color.nrSignal : Color.nrTextFaint)
                    .clipShape(NotchedRect())
            }
            .disabled(!canImportPasted)
        }
    }

    private var canImportPasted: Bool {
        !pastedText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    private func errorBanner(_ message: String) -> some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: "exclamationmark.triangle.fill")
                .foregroundStyle(Color.nrAlert)
            Text(message)
                .font(NRFont.caption)
                .foregroundStyle(Color.nrTextPrimary)
        }
        .padding(NRMetrics.cardPadding)
        .nrPanel(fill: Color.nrAlert.opacity(0.12), edge: Color.nrAlert)
    }

    // MARK: - Actions

    private func handleFileResult(_ result: Result<[URL], Error>) {
        switch result {
        case .success(let urls):
            guard let url = urls.first else { return }
            if store.importConfig(from: url) != nil {
                dismiss()
            } else {
                localError = store.importError
            }
        case .failure(let error):
            localError = error.localizedDescription
        }
    }

    private func importPasted() {
        let name = nameForPaste.trimmingCharacters(in: .whitespaces)
        let resolvedName = name.isEmpty ? "Imported node" : name
        if store.importConfig(text: pastedText, suggestedName: resolvedName) != nil {
            dismiss()
        } else {
            localError = store.importError
        }
    }
}

#Preview {
    ImportConfigView()
}
