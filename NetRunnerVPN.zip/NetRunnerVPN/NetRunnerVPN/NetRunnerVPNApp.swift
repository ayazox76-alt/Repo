//
//  NetRunnerVPNApp.swift
//  NetRunner VPN
//

import SwiftUI

@main
struct NetRunnerVPNApp: App {
    var body: some Scene {
        WindowGroup {
            HomeView()
        }
    }
}
