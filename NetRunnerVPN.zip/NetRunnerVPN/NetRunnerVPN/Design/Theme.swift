//
//  Theme.swift
//  NetRunner VPN
//
//  Design tokens: colors, type, metrics. One source of truth for the
//  whole app's "night city HUD" aesthetic. Change values here, not at
//  call sites.
//

import SwiftUI

// MARK: - Color tokens

extension Color {
    /// Base background — almost black, faint cold blue undertone.
    static let nrVoid = Color(hex: 0x0A0E14)

    /// Raised surface — cards, sheets, the server list rows sit on this.
    static let nrSurface = Color(hex: 0x141A24)

    /// Slightly higher surface, for nested elements / pressed states.
    static let nrSurfaceRaised = Color(hex: 0x1C2433)

    /// Hairline borders, dividers, the etched-panel edges.
    static let nrEdge = Color(hex: 0x2A3344)

    /// Primary accent — signal yellow, used for the active/primary action only.
    static let nrSignal = Color(hex: 0xF4D03F)

    /// Secondary accent — cyan, used for network/data indicators.
    static let nrCyan = Color(hex: 0x00F0FF)

    /// Alert / disconnect / error.
    static let nrAlert = Color(hex: 0xFF2B4D)

    /// Primary text.
    static let nrTextPrimary = Color(hex: 0xE8EBF0)

    /// Secondary / muted text.
    static let nrTextMuted = Color(hex: 0x7A8699)

    /// Tertiary / faint labels, eyebrow text.
    static let nrTextFaint = Color(hex: 0x4A5468)

    init(hex: UInt32, opacity: Double = 1.0) {
        self.init(
            .sRGB,
            red: Double((hex >> 16) & 0xFF) / 255,
            green: Double((hex >> 8) & 0xFF) / 255,
            blue: Double(hex & 0xFF) / 255,
            opacity: opacity
        )
    }
}

// MARK: - Type tokens

enum NRFont {
    /// Monospace — for data: IPs, keys, throughput, timers. The "machine voice."
    static func mono(_ size: CGFloat, weight: Font.Weight = .regular) -> Font {
        .system(size: size, weight: weight, design: .monospaced)
    }

    /// Grotesk — for UI copy, labels, anything a human reads as a sentence.
    static func ui(_ size: CGFloat, weight: Font.Weight = .regular) -> Font {
        .system(size: size, weight: weight, design: .rounded)
    }

    static let displayLarge = ui(34, weight: .bold)
    static let displayMedium = ui(22, weight: .semibold)
    static let body = ui(16, weight: .regular)
    static let caption = ui(13, weight: .medium)
    static let eyebrow = mono(11, weight: .semibold)
    static let dataLarge = mono(28, weight: .semibold)
    static let dataMedium = mono(15, weight: .medium)
    static let dataSmall = mono(12, weight: .regular)
}

// MARK: - Shape tokens

/// CP2077-style cut corner: one corner notched instead of rounded.
/// Used in place of RoundedRectangle for an "etched panel" feel.
struct NotchedRect: Shape {
    var notch: CGFloat = 14

    func path(in rect: CGRect) -> Path {
        var p = Path()
        p.move(to: CGPoint(x: rect.minX, y: rect.minY))
        p.addLine(to: CGPoint(x: rect.maxX - notch, y: rect.minY))
        p.addLine(to: CGPoint(x: rect.maxX, y: rect.minY + notch))
        p.addLine(to: CGPoint(x: rect.maxX, y: rect.maxY))
        p.addLine(to: CGPoint(x: rect.minX + notch, y: rect.maxY))
        p.addLine(to: CGPoint(x: rect.minX, y: rect.maxY - notch))
        p.closeSubpath()
        return p
    }
}

struct NRPanel: ViewModifier {
    var fill: Color = .nrSurface
    var edge: Color = .nrEdge

    func body(content: Content) -> some View {
        content
            .background(fill)
            .clipShape(NotchedRect())
            .overlay(NotchedRect().stroke(edge, lineWidth: 1))
    }
}

extension View {
    func nrPanel(fill: Color = .nrSurface, edge: Color = .nrEdge) -> some View {
        modifier(NRPanel(fill: fill, edge: edge))
    }
}

// MARK: - Metrics

enum NRMetrics {
    static let pageMargin: CGFloat = 20
    static let cardPadding: CGFloat = 16
    static let stackGap: CGFloat = 12
}
