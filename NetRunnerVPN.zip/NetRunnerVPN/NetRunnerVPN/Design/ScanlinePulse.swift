//
//  ScanlinePulse.swift
//  NetRunner VPN
//
//  The app's signature element: a thin band of light that sweeps across
//  the active server card, like a signal moving through the network.
//  Speeds up while connecting, settles to a slow idle sweep once the
//  tunnel is live, and freezes/reddens on failure.
//

import SwiftUI

enum NRLinkState {
    case idle
    case connecting
    case connected
    case failed

    var tint: Color {
        switch self {
        case .idle: return .nrTextFaint
        case .connecting: return .nrCyan
        case .connected: return .nrSignal
        case .failed: return .nrAlert
        }
    }

    var sweepDuration: Double {
        switch self {
        case .idle: return 0
        case .connecting: return 0.6
        case .connected: return 2.6
        case .failed: return 0
        }
    }
}

struct ScanlinePulse: View {
    var state: NRLinkState
    @State private var sweep: CGFloat = -0.3

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .leading) {
                Rectangle()
                    .fill(Color.nrEdge)
                    .frame(height: 2)

                if state != .idle {
                    LinearGradient(
                        colors: [.clear, state.tint, .clear],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                    .frame(width: geo.size.width * 0.4, height: 2)
                    .offset(x: sweep * geo.size.width)
                    .blendMode(.plusLighter)
                }
            }
            .onAppear { animate() }
            .onChange(of: state) { _, _ in animate() }
        }
        .frame(height: 2)
    }

    private func animate() {
        guard state.sweepDuration > 0 else { return }
        sweep = -0.3
        withAnimation(.linear(duration: state.sweepDuration).repeatForever(autoreverses: false)) {
            sweep = 1.1
        }
    }
}

/// Small glitch-jitter applied to status text when the link state changes —
/// a one-shot flicker, not a looping animation, so it reads as an event.
struct GlitchOnChange: ViewModifier {
    let trigger: AnyHashable
    @State private var offset: CGFloat = 0

    func body(content: Content) -> some View {
        content
            .offset(x: offset)
            .onChange(of: trigger) { _, _ in
                let steps: [CGFloat] = [-3, 2, -1, 0]
                for (i, step) in steps.enumerated() {
                    DispatchQueue.main.asyncAfter(deadline: .now() + Double(i) * 0.035) {
                        offset = step
                    }
                }
            }
    }
}

extension View {
    func nrGlitch(on trigger: AnyHashable) -> some View {
        modifier(GlitchOnChange(trigger: trigger))
    }
}
