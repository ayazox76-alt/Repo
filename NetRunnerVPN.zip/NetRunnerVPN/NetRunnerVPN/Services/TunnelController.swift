//
//  TunnelController.swift
//  NetRunner VPN
//
//  Owns the NETunnelProviderManager lifecycle: create/update the system
//  VPN profile, start/stop the tunnel, and surface connection status to
//  the UI. Talks to the PacketTunnelProvider extension (NetRunnerVPNTunnel
//  target) which does the actual WireGuard/AmneziaWG work via WireGuardKit.
//
//  NOTE: this file assumes the WireGuardKit Swift package (amnezia-vpn
//  fork, which understands the Jc/Jmin/Jmax/S1/S2/H1-H4 keys) has been
//  added to the project — see README for the exact SPM URL and the
//  manual build-target steps WireGuardKit's own README requires for the
//  Go bridge static library.
//

import Foundation
import NetworkExtension
import Combine

@MainActor
final class TunnelController: ObservableObject {
    static let shared = TunnelController()

    @Published private(set) var linkState: NRLinkState = .idle
    @Published private(set) var activeProfileID: UUID?
    @Published private(set) var lastError: String?

    /// Bundle identifier of the Packet Tunnel Provider extension target.
    /// Must match NetRunnerVPNTunnel's Info.plist / entitlements exactly.
    private let tunnelBundleID = "com.yourteam.netrunnervpn.tunnel"

    private var manager: NETunnelProviderManager?
    private var statusObserver: NSObjectProtocol?

    private init() {
        Task { await loadOrCreateManager() }
    }

    // MARK: - Manager lifecycle

    private func loadOrCreateManager() async {
        do {
            let managers = try await NETunnelProviderManager.loadAllFromPreferences()
            manager = managers.first ?? NETunnelProviderManager()
            observeStatus()
        } catch {
            lastError = "Could not load VPN preferences: \(error.localizedDescription)"
        }
    }

    private func observeStatus() {
        guard let session = manager?.connection as? NETunnelProviderSession else { return }
        statusObserver = NotificationCenter.default.addObserver(
            forName: .NEVPNStatusDidChange,
            object: session,
            queue: .main
        ) { [weak self] _ in
            Task { @MainActor in self?.syncState(from: session.status) }
        }
        syncState(from: session.status)
    }

    private func syncState(from status: NEVPNStatus) {
        switch status {
        case .connected: linkState = .connected
        case .connecting, .reasserting: linkState = .connecting
        case .disconnecting: linkState = .connecting
        case .disconnected: linkState = .idle
        case .invalid: linkState = .failed
        @unknown default: linkState = .idle
        }
    }

    // MARK: - Connect / disconnect

    /// Pushes `profile` into the system VPN configuration and starts the
    /// tunnel. AmneziaWG obfuscation parameters travel inside
    /// `protocolConfiguration.providerConfiguration` as plain key/value
    /// pairs that the extension's PacketTunnelProvider reads back out
    /// when it builds the WireGuardKit TunnelConfiguration.
    func connect(to profile: ServerProfile) async {
        guard let manager else { return }
        lastError = nil
        linkState = .connecting

        let proto = NETunnelProviderProtocol()
        proto.providerBundleIdentifier = tunnelBundleID
        proto.serverAddress = profile.hostOnly
        proto.providerConfiguration = providerConfig(for: profile)

        manager.protocolConfiguration = proto
        manager.localizedDescription = profile.name
        manager.isEnabled = true

        do {
            try await manager.saveToPreferences()
            try await manager.loadFromPreferences()
            try (manager.connection as? NETunnelProviderSession)?.startTunnel()
            activeProfileID = profile.id
        } catch {
            linkState = .failed
            lastError = error.localizedDescription
        }
    }

    func disconnect() {
        (manager?.connection as? NETunnelProviderSession)?.stopTunnel()
        activeProfileID = nil
    }

    /// Serializes every field WireGuardKit / AmneziaWG's PacketTunnelProvider
    /// side needs to bring the interface up. Keys mirror the .conf names so
    /// the extension-side mapping stays obvious.
    private func providerConfig(for p: ServerProfile) -> [String: Any] {
        var config: [String: Any] = [
            "PrivateKey": p.privateKey,
            "Address": p.address,
            "PublicKey": p.publicKey,
            "Endpoint": p.endpoint,
            "AllowedIPs": p.allowedIPs,
        ]
        if let dns = p.dns { config["DNS"] = dns }
        if let mtu = p.mtu { config["MTU"] = mtu }
        if let psk = p.presharedKey { config["PresharedKey"] = psk }
        if let ka = p.persistentKeepalive { config["PersistentKeepalive"] = ka }

        if let jc = p.junkPacketCount { config["Jc"] = jc }
        if let jmin = p.junkPacketMinSize { config["Jmin"] = jmin }
        if let jmax = p.junkPacketMaxSize { config["Jmax"] = jmax }
        if let s1 = p.initHeaderJunkSize { config["S1"] = s1 }
        if let s2 = p.responseHeaderJunkSize { config["S2"] = s2 }
        if let h1 = p.initPacketMagicHeader { config["H1"] = h1 }
        if let h2 = p.responsePacketMagicHeader { config["H2"] = h2 }
        if let h3 = p.underloadPacketMagicHeader { config["H3"] = h3 }
        if let h4 = p.transportPacketMagicHeader { config["H4"] = h4 }

        return config
    }
}
