//
//  ServerStore.swift
//  NetRunner VPN
//
//  Persists the list of imported server profiles to disk (JSON in the
//  app's Application Support directory) and exposes it as published
//  state for the UI. Keys/secrets live in plain JSON here for clarity;
//  swap the load/save pair for Keychain-backed storage before shipping
//  to production — see README "Before you ship" section.
//

import Foundation
import Combine

@MainActor
final class ServerStore: ObservableObject {
    static let shared = ServerStore()

    @Published private(set) var profiles: [ServerProfile] = []
    @Published var importError: String?

    private let fileURL: URL

    private init() {
        let dir = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        fileURL = dir.appendingPathComponent("servers.json")
        load()
    }

    // MARK: - CRUD

    func add(_ profile: ServerProfile) {
        profiles.append(profile)
        save()
    }

    func remove(_ profile: ServerProfile) {
        profiles.removeAll { $0.id == profile.id }
        save()
    }

    func rename(_ profile: ServerProfile, to newName: String) {
        guard let idx = profiles.firstIndex(where: { $0.id == profile.id }) else { return }
        profiles[idx].name = newName
        save()
    }

    func recordPing(_ millis: Int?, for profile: ServerProfile) {
        guard let idx = profiles.firstIndex(where: { $0.id == profile.id }) else { return }
        profiles[idx].lastPingMillis = millis
        save()
    }

    func markConnected(_ profile: ServerProfile) {
        guard let idx = profiles.firstIndex(where: { $0.id == profile.id }) else { return }
        profiles[idx].lastConnectedAt = Date()
        save()
    }

    // MARK: - Import

    /// Imports a .conf file from a URL (e.g. delivered via the Files share
    /// sheet or a document picker). Returns the parsed profile on success.
    @discardableResult
    func importConfig(from url: URL) -> ServerProfile? {
        let needsAccess = url.startAccessingSecurityScopedResource()
        defer { if needsAccess { url.stopAccessingSecurityScopedResource() } }

        do {
            let text = try String(contentsOf: url, encoding: .utf8)
            let suggestedName = url.deletingPathExtension().lastPathComponent
            let profile = try ConfigImporter.parse(text, suggestedName: suggestedName)
            add(profile)
            importError = nil
            return profile
        } catch {
            importError = error.localizedDescription
            return nil
        }
    }

    @discardableResult
    func importConfig(text: String, suggestedName: String) -> ServerProfile? {
        do {
            let profile = try ConfigImporter.parse(text, suggestedName: suggestedName)
            add(profile)
            importError = nil
            return profile
        } catch {
            importError = error.localizedDescription
            return nil
        }
    }

    // MARK: - Persistence

    private func load() {
        guard let data = try? Data(contentsOf: fileURL) else { return }
        profiles = (try? JSONDecoder().decode([ServerProfile].self, from: data)) ?? []
    }

    private func save() {
        guard let data = try? JSONEncoder().encode(profiles) else { return }
        try? data.write(to: fileURL, options: .atomic)
    }
}
