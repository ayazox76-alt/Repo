//
//  ConfigImporter.swift
//  NetRunner VPN
//
//  Parses standard WireGuard .conf INI-style files, including the
//  AmneziaWG extension keys (Jc, Jmin, Jmax, S1, S2, H1-H4) that live
//  in the [Interface] section of an AmneziaWG-flavored config.
//
//  Reference format (AmneziaWG native export):
//
//  [Interface]
//  PrivateKey = ...
//  Address = 10.8.1.2/32
//  DNS = 1.1.1.1
//  Jc = 4
//  Jmin = 40
//  Jmax = 70
//  S1 = 0
//  S2 = 0
//  H1 = 1234567890
//  H2 = 1234567891
//  H3 = 1234567892
//  H4 = 1234567893
//
//  [Peer]
//  PublicKey = ...
//  PresharedKey = ...
//  Endpoint = 203.0.113.5:51820
//  AllowedIPs = 0.0.0.0/0, ::/0
//  PersistentKeepalive = 25
//

import Foundation

enum ConfigImportError: LocalizedError {
    case missingSection(String)
    case missingKey(String)
    case malformed(String)

    var errorDescription: String? {
        switch self {
        case .missingSection(let s): return "Config has no [\(s)] section."
        case .missingKey(let k): return "Config is missing required key \"\(k)\"."
        case .malformed(let detail): return "Could not parse config: \(detail)"
        }
    }
}

struct ConfigImporter {

    /// Parses raw .conf text into a ServerProfile. `suggestedName` is used
    /// as a fallback display name (typically the filename without extension).
    static func parse(_ text: String, suggestedName: String) throws -> ServerProfile {
        let sections = splitSections(text)

        guard let iface = sections["interface"] else {
            throw ConfigImportError.missingSection("Interface")
        }
        guard let peer = sections["peer"] else {
            throw ConfigImportError.missingSection("Peer")
        }

        guard let privateKey = iface["privatekey"] else {
            throw ConfigImportError.missingKey("PrivateKey")
        }
        guard let address = iface["address"] else {
            throw ConfigImportError.missingKey("Address")
        }
        guard let publicKey = peer["publickey"] else {
            throw ConfigImportError.missingKey("PublicKey")
        }
        guard let endpoint = peer["endpoint"] else {
            throw ConfigImportError.missingKey("Endpoint")
        }

        return ServerProfile(
            name: suggestedName,
            privateKey: privateKey,
            address: address,
            dns: iface["dns"],
            mtu: iface["mtu"].flatMap(Int.init),
            publicKey: publicKey,
            presharedKey: peer["presharedkey"],
            endpoint: endpoint,
            allowedIPs: peer["allowedips"] ?? "0.0.0.0/0, ::/0",
            persistentKeepalive: peer["persistentkeepalive"].flatMap(Int.init),
            junkPacketCount: iface["jc"].flatMap(Int.init),
            junkPacketMinSize: iface["jmin"].flatMap(Int.init),
            junkPacketMaxSize: iface["jmax"].flatMap(Int.init),
            initHeaderJunkSize: iface["s1"].flatMap(Int.init),
            responseHeaderJunkSize: iface["s2"].flatMap(Int.init),
            initPacketMagicHeader: iface["h1"].flatMap(UInt32.init),
            responsePacketMagicHeader: iface["h2"].flatMap(UInt32.init),
            underloadPacketMagicHeader: iface["h3"].flatMap(UInt32.init),
            transportPacketMagicHeader: iface["h4"].flatMap(UInt32.init)
        )
    }

    /// Splits INI-style text into lowercase-keyed sections, lowercase-keyed
    /// key/value maps. Ignores blank lines and lines starting with '#' or ';'.
    private static func splitSections(_ text: String) -> [String: [String: String]] {
        var sections: [String: [String: String]] = [:]
        var currentSection: String?

        for rawLine in text.split(separator: "\n", omittingEmptySubsequences: false) {
            let line = rawLine.trimmingCharacters(in: .whitespaces)
            guard !line.isEmpty, !line.hasPrefix("#"), !line.hasPrefix(";") else { continue }

            if line.hasPrefix("["), line.hasSuffix("]") {
                let name = String(line.dropFirst().dropLast()).lowercased()
                currentSection = name
                if sections[name] == nil { sections[name] = [:] }
                continue
            }

            guard let section = currentSection,
                  let eqIndex = line.firstIndex(of: "=") else { continue }

            let key = line[line.startIndex..<eqIndex]
                .trimmingCharacters(in: .whitespaces)
                .lowercased()
            let value = line[line.index(after: eqIndex)...]
                .trimmingCharacters(in: .whitespaces)

            sections[section, default: [:]][key] = value
        }

        return sections
    }

    /// Serializes a ServerProfile back to AmneziaWG-flavored .conf text —
    /// used for export / backup / sharing a profile between devices.
    static func serialize(_ profile: ServerProfile) -> String {
        var lines = ["[Interface]"]
        lines.append("PrivateKey = \(profile.privateKey)")
        lines.append("Address = \(profile.address)")
        if let dns = profile.dns { lines.append("DNS = \(dns)") }
        if let mtu = profile.mtu { lines.append("MTU = \(mtu)") }
        if let jc = profile.junkPacketCount { lines.append("Jc = \(jc)") }
        if let jmin = profile.junkPacketMinSize { lines.append("Jmin = \(jmin)") }
        if let jmax = profile.junkPacketMaxSize { lines.append("Jmax = \(jmax)") }
        if let s1 = profile.initHeaderJunkSize { lines.append("S1 = \(s1)") }
        if let s2 = profile.responseHeaderJunkSize { lines.append("S2 = \(s2)") }
        if let h1 = profile.initPacketMagicHeader { lines.append("H1 = \(h1)") }
        if let h2 = profile.responsePacketMagicHeader { lines.append("H2 = \(h2)") }
        if let h3 = profile.underloadPacketMagicHeader { lines.append("H3 = \(h3)") }
        if let h4 = profile.transportPacketMagicHeader { lines.append("H4 = \(h4)") }

        lines.append("")
        lines.append("[Peer]")
        lines.append("PublicKey = \(profile.publicKey)")
        if let psk = profile.presharedKey { lines.append("PresharedKey = \(psk)") }
        lines.append("Endpoint = \(profile.endpoint)")
        lines.append("AllowedIPs = \(profile.allowedIPs)")
        if let keepalive = profile.persistentKeepalive {
            lines.append("PersistentKeepalive = \(keepalive)")
        }

        return lines.joined(separator: "\n")
    }
}
