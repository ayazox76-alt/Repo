//
//  ServerProfile.swift
//  NetRunner VPN
//
//  A single importable node: standard WireGuard fields plus the
//  AmneziaWG obfuscation parameters (Jc/Jmin/Jmax junk packets,
//  S1/S2 padding, H1-H4 packet header magic values).
//

import Foundation

struct ServerProfile: Identifiable, Codable, Equatable {
    let id: UUID
    var name: String

    // Interface
    var privateKey: String
    var address: String
    var dns: String?
    var mtu: Int?

    // Peer
    var publicKey: String
    var presharedKey: String?
    var endpoint: String
    var allowedIPs: String
    var persistentKeepalive: Int?

    // AmneziaWG obfuscation parameters — nil means "plain WireGuard,
    // no obfuscation," which keeps this struct backward compatible
    // with vanilla .conf files.
    var junkPacketCount: Int?          // Jc
    var junkPacketMinSize: Int?        // Jmin
    var junkPacketMaxSize: Int?        // Jmax
    var initHeaderJunkSize: Int?       // S1
    var responseHeaderJunkSize: Int?   // S2
    var initPacketMagicHeader: UInt32? // H1
    var responsePacketMagicHeader: UInt32? // H2
    var underloadPacketMagicHeader: UInt32? // H3
    var transportPacketMagicHeader: UInt32? // H4

    var lastConnectedAt: Date?
    var lastPingMillis: Int?

    init(
        id: UUID = UUID(),
        name: String,
        privateKey: String,
        address: String,
        dns: String? = nil,
        mtu: Int? = nil,
        publicKey: String,
        presharedKey: String? = nil,
        endpoint: String,
        allowedIPs: String = "0.0.0.0/0, ::/0",
        persistentKeepalive: Int? = 25,
        junkPacketCount: Int? = nil,
        junkPacketMinSize: Int? = nil,
        junkPacketMaxSize: Int? = nil,
        initHeaderJunkSize: Int? = nil,
        responseHeaderJunkSize: Int? = nil,
        initPacketMagicHeader: UInt32? = nil,
        responsePacketMagicHeader: UInt32? = nil,
        underloadPacketMagicHeader: UInt32? = nil,
        transportPacketMagicHeader: UInt32? = nil,
        lastConnectedAt: Date? = nil,
        lastPingMillis: Int? = nil
    ) {
        self.id = id
        self.name = name
        self.privateKey = privateKey
        self.address = address
        self.dns = dns
        self.mtu = mtu
        self.publicKey = publicKey
        self.presharedKey = presharedKey
        self.endpoint = endpoint
        self.allowedIPs = allowedIPs
        self.persistentKeepalive = persistentKeepalive
        self.junkPacketCount = junkPacketCount
        self.junkPacketMinSize = junkPacketMinSize
        self.junkPacketMaxSize = junkPacketMaxSize
        self.initHeaderJunkSize = initHeaderJunkSize
        self.responseHeaderJunkSize = responseHeaderJunkSize
        self.initPacketMagicHeader = initPacketMagicHeader
        self.responsePacketMagicHeader = responsePacketMagicHeader
        self.underloadPacketMagicHeader = underloadPacketMagicHeader
        self.transportPacketMagicHeader = transportPacketMagicHeader
        self.lastConnectedAt = lastConnectedAt
        self.lastPingMillis = lastPingMillis
    }

    /// True if any AmneziaWG obfuscation field is set — used to show the
    /// "AWG" badge vs a plain "WG" badge in the server list.
    var usesObfuscation: Bool {
        junkPacketCount != nil || initPacketMagicHeader != nil
    }

    var hostOnly: String {
        endpoint.split(separator: ":").first.map(String.init) ?? endpoint
    }
}
